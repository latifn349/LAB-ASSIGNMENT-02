#include <stdio.h>
int main(){
int N=5,i;
printf("enter N:");
scanf("%d",i);
for(i=1; i<=N; i++){
printf("%d",i);
}
return 0;
}

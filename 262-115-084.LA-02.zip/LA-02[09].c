#include <stdio.h>
int main()
{
int N,i;
long long fact=1;
printf("enter N:");
scanf("%d",&N);
if(N<0||N>20){
printf("enter a number from 0 to 29.");
}else {
for(i=1; i<=N; i++){
fact=fact*i;
}
printf("Factorial=%11d",fact);
}
return 0;
}

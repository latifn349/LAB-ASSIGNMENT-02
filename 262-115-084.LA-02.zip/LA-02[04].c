#include <stdio.h>
int main(){
int N, i, sum=0;
printf("enter N:");
scanf("%d",&N);
for(i=2; i<=N; i+=2){
sum=sum+i;
}
printf("sum of even numbers=%d", sum);
return 0;
}

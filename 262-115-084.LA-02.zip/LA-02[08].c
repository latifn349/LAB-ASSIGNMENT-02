#include <stdio.h>
int main(){
int n, digit, sum=0;
printf("enter a number:");
scanf("%d",&n);
if(n<0){
n=-n;
}
while(n>0){
digit=n%10;
sum=sum+digit;
n=n/10;
}
printf("sum of digits=%d",sum);
return 0;
}
